import { LightningElement } from 'lwc';

export default class LwcLayoutDemo extends LightningElement {}