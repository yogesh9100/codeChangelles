import { LightningElement } from 'lwc';

export default class PubsubParentComponent extends LightningElement {}